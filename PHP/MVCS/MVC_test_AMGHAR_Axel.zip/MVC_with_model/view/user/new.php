
<a href="<?php echo ROOT ?>user/liste">< Retour</a><br>

<H1>Ajouter un utilisateur</H1>
<form action="<?php echo ROOT?>user/ajouter" method="post">
    <label for="">Nom user:</label>
    <input type="text" name="name" value="AMGHAR Axel" required/><br>
    <input type="submit" />
</form>